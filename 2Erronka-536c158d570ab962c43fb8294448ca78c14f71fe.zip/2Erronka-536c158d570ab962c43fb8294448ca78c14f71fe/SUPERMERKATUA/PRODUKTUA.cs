﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SUPERMERKATUA
{
    public class Produktua
    {
        public int Id { get; set; }
        public string Izena { get; set; }
        public string Kategoria { get; set; }

        public Produktua() { }
    }
}
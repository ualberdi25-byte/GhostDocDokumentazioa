﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SUPERMERKATUA
{
    public class Saltzailea
    {
        // GET-SET
        public int Id { get; set; }
        public string Izena { get; set; }
        public string Nan { get; set; }

        public Saltzailea() { } // KONSTRUKTOREA HUTSIK
    }
}
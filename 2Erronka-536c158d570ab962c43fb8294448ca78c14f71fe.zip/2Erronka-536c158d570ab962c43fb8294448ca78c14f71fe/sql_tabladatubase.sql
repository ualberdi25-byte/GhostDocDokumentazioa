CREATE DATABASE supermercado;
USE supermercado;
CREATE TABLE saltzailea (
    id_saltzailea INT AUTO_INCREMENT PRIMARY KEY,
    izena VARCHAR(50) NOT NULL,
    nan VARCHAR(15) NOT NULL
);
CREATE TABLE produktua (
    id_produktua INT AUTO_INCREMENT PRIMARY KEY,
    izena VARCHAR(50) NOT NULL,
    kategoria VARCHAR(50) NOT NULL
);
CREATE TABLE ticketa (
    id_ticket INT AUTO_INCREMENT PRIMARY KEY,
    data DATETIME NOT NULL,
    kantitatea DECIMAL(10,2) NOT NULL,
    prezioakg DECIMAL(10,2) NOT NULL,
    totala DECIMAL(10,2) NOT NULL,
    id_saltzailea INT NOT NULL,
    id_produktua INT NOT NULL,

    CONSTRAINT fk_ticket_saltzailea
        FOREIGN KEY (id_saltzailea)
        REFERENCES saltzailea(id_saltzailea),

    CONSTRAINT fk_ticket_produktua
        FOREIGN KEY (id_produktua)
        REFERENCES produktua(id_produktua)
);
